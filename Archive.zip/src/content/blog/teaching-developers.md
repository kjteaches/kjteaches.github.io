---
title: "Notes on teaching and developer education"
description: "They came into my house, ate my porridge, slept in my bed oh my days"
featured: true
order: 6
draft: false
---

> And so it is that you, by reasons of your tender regard for the writing that is your offspring, have declared the very opposite of its true effect.
>
> If men learn this, it will implant forgetfulness in their souls; they will cease to exercise memory because they rely on that which is written, calling things to remembrance no longer from within themselves, but by means of external marks.
>
> What you have discovered is a recipe not for memory, but for reminder.
>
> And it is no true wisdom that you offer your disciples, but only its semblance, for by telling them of many things without teaching them you will make them seem to know much, while for the most part they know nothing, and as men filled, not with wisdom but with the conceit of wisdom, they will be a burden to their fellows.'

You probably skipped most of that opening block but I strongly recommend going back and reading it. It's worth it, I promise.

That was [written by Plato](https://websites.umich.edu/~lsarth/filecabinet/PlatoOnWriting.html), who was quoting Socrates quoting something someone else said, in a conversation with someone called Phaedrus.

Either way, it doesn't matter who said what, but rather _when_ it was said, because that text is from 360 BCE. A full good-googly-moogly years before I was born!

We've always been like this.

We should learn, but only verbally, not writing.

We should learn, but only [through handwritten manuscripts](https://archive.org/details/inpraiseofscribe0000trit), not printed books.

We should learn, but only through printed books, not that dang phone.

When I was learning software development, I received similar warnings about the dangers of relying on code completion and formatters.
